console.log(20+30);

console.log(typeof console);
console.log(typeof log);
console.log(10+20+30+40+50+60+70+80+90);