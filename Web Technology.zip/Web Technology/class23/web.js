// let Mahi= function (){
//     console.log("iam Indian");
// }
// Mahi()

// function x(){
//     var a=20;
//     console.log(a);
//     let b=30;
//     console.log(b);
// }

// function x(a,b){
//     console.log(a+b);
// }

console.log("Start");
    var a=30;
    let b=40;
    console.log(a);
    console.log(b);
    function maahi(){
        var x=200;
        let y=500;
        const z=600;
        console.log(x);
        console.log(y);
        console.log(z);
    }
    maahi()
