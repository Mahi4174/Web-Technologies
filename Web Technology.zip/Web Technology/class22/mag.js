// let x="INCRADIBLE INDIA"
// console.log(x);
// console.log(x.charAt(4));
// console.log(x.indexOf("I"));
// console.log(x.lastIndexOf("I"));
// console.log(x.length);
// console.log(x.slice(2,6));
// console.log(x.toLocaleLowerCase());
// console.log(x.toLocaleUpperCase());
// console.log(x.replace('D','O'));
// console.log(x.split("").reverse().join());



// console.log("start");
// console.log(a);
// let a=200;
// console.log(a);
// let z=300;
// console.log(z);
// const y=500;
// console.log(y);



console.log("start");
let b=20;
var a=30;
console.log(b);
console.log(a);