# Completely built with Html5,Css3 & Javascript

# HotstarClone

# user can choose the movies from different geners

# Also User Can Watch regional language movies also

# Screenshots

![Optional Text](./assests/1.png)
![Optional Text](./assests/2.png)

## Deployed Site

https://jovial-knuth-52283b.netlify.app
