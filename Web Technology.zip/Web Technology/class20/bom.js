// console.log("My Name Is P Mahendra");

// console.log(prompt("Enter Your Name"));
// console.log(alert("Yes Your Name Is P Mahendra"));
// console.log(confirm("Yes Its True"));

// document.write("Mahendra")
// document.writeln("P Mahendra Mahi")
// document.write("Mahendra P")

// console.log(prompt("ht"));
// console.log(alert("huhn"));
// console.log(confirm("yjhy"));


// var a=100;
// console.log(a);


// let b=10;
// console.log(b);


// a=40
// console.log(a);
// console.log(20+30);
// console.log(20*30);
// console.log(20/30);
// document.write(20)

let x=prompt("Enter First Value")
let y=prompt("Enter Second Number")

console.log(x+y)
console.log(x*y);

// console.log(10+'20');
// console.log(10+20);
