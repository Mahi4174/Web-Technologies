// let arr=[100,200,300,400,500]
// console.log(arr);
// console.log(typeof arr);

// console.log(typeof arr);
// console.log(typeof Array);
// console.log(Array.isArray(arr));

// console.log(arr===Array);

// let x="100";
// console.log(x==="100");

// // console.log(arr.fill(5));
// console.log(arr.indexOf(300));
// console.log(arr.length);

// console.log(arr);
// console.log(arr.slice(1,4));
// console.log(arr.splice(1,3,"hello"));
// console.log(arr);
// console.log(arr);
// console.log(arr.push(600));
// console.log(arr);
// console.log(arr.pop());
// console.log(arr);
// console.log(arr.shift());
// console.log(arr);
// console.log(arr.unshift(10));
// console.log(arr);







let arr1=[300,5000,1000,4000,800,500]
console.log(arr1);
let res=arr1.filter((m)=>{
    return m<1000;
})
console.log(res);

let res1=res.map((x)=>{
    return x+x*18/100
})
console.log(res1);


let res2=arr1.reduce((x,y)=>{
    return x*y
},200)
console.log(res2);