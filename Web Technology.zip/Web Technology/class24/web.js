// console.log("Start");
// var a=20;
// let b=30;
// console.log(b);
// console.log(a);
// function x(){
//     let w=40;
//     function y(){
//         console.log(w);
//         var z=50;
//         console.log(z);
//     }
//     y()
// }
// x()

let a=10;
let b=20;
console.log(a,b);
function oneFunction() {
    let c=30;
    let d=40;
    function twoFunction() {
        let e=50;
        console.log(c);
        console.log(d);
        function threeFumction() {
            console.log(e);
        }
        return threeFumction;
    }
    return twoFunction
}
oneFunction()();